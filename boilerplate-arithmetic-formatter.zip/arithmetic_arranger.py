import re
def preprocess(s,display):
    operand=re.findall(r'\d+',s)
    operator=re.findall(r'[^\d ]',s)
    if len(operand)>2 or len(operator)>1:
        return "Error: Numbers must only contain digits."
    if len(operand[0])>4 or len(operand[1])>4:
        return "Error: Numbers cannot be more than four digits."
    if not (operator[0] in ('-','+') ):
        return "Error: Operator must be '+' or '-'."
    maxlen=max(len(operand[0]),len(operand[1]))
    block=[operand[0].rjust(maxlen+2),operator[0]+' '+operand[1].rjust(maxlen),'-'*(maxlen+2)]
    if display:
        if operator[0]=='-':
            block.append(str(int(operand[0])-int(operand[1])).rjust(maxlen+2))
        if operator[0]=='+':
            block.append(str(int(operand[0])+int(operand[1])).rjust(maxlen+2))
    return block

def arithmetic_arranger(problems,display=False):
    if len(problems)>5 :
        return "Error: Too many problems."
    seperator=' '*4

    blocks=[]
    for s in problems:
        blocks.append(preprocess(s,display))
        if type(blocks[-1])==str:
            return blocks[-1]

    arranged_problems=''
    if display==True:
        count=4
    else:
        count=3
    for i in range(count):
        for j in blocks:
            arranged_problems+=j[i]+seperator
            if j==blocks[-1]:
                arranged_problems=arranged_problems[0:-4]
        arranged_problems+='\n'
    return arranged_problems[0:-1]


if __name__ == "__main__":
    print(arithmetic_arranger(["44 + 815", "909 - 2", "45 + 43", "123 + 49", "888 + 40", "653 + 87"]))  

# import re

# ERR_SIZE = "Error: Too many problems."
# ERR_OP = "Error: Operator must be '+' or '-'."
# ERR_NUM = "Error: Numbers must only contain digits."
# ERR_LEN = "Error: Numbers cannot be more than four digits."


# def arithmetic_arranger(problems, calc=False):
#     """
#     :type problems: list
#     """
#     if len(problems) > 5:
#         return ERR_SIZE

#     rex = re.compile(r'^[0-9]{1,4}$')

#     formated = []

#     for p in problems:
#         [a, op, b] = p.split()

#         # check the operator
#         if op != '+' and op != "-":
#             return ERR_OP

#         if len(a) > 4 or len(b) > 4:
#             return ERR_LEN

#         if rex.match(a) is None or rex.match(b) is None:
#             return ERR_NUM

#         formated.append(fmt(a, op, b, calc))

#     ss = formated[0]
#     spaces = " " * 4
#     for p in formated[1:]:
#         for i in range(0, len(ss)):
#             ss[i] += spaces + p[i]

#     if not calc:
#         ss = ss[0:3]

#     return '\n'.join(ss)


# def fmt(a, op, b, calc):
#     x = int(a)
#     y = int(b)
#     r = x + y if op == '+' else x - y
#     base = r if r > 0 else 0 - r
#     n = max([len(a), len(b), len(str(base))]) if calc else max([len(a), len(b)])

#     r = str(r)
#     n += 2  # for the op and a space
#     res = [a.rjust(n), op + " " + b.rjust(n - 2), '-' * n]
#     if calc:
#         res.append(r.rjust(n))
#     return res

